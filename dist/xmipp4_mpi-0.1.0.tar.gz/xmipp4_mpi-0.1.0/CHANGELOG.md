# Release v0.1.0
Initial xmipp4-mpi release. Still work in progress.

- Up to date communication interface implementation with the MPI backend
